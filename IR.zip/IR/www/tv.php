<?php
$metarefresh = '<meta http-equiv="refresh" content="0; url=/" />';
#$msg = 'le message';
?>
<html>
    <head>
       <?php
        // affichage du meta de redirection 
        echo $metarefresh;
pclose(popen(tv . ' &', 'r'))
        ?>
    </head>
#    <body>
#        <?php
#        // affichage du message vu par le visiteur
#        echo $msg;
#        ?>
#    </body>
</html>
#
#<?php
# header("location:", $_SERVER['HTTP_REFERER']);
#  pclose(popen(tv . ' &', 'r'))
# shell_exec("tv 2>/dev/null >/dev/null &");