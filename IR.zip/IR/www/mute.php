<?php
$metarefresh = '<meta http-equiv="refresh" content="0; url=/" />';
?>
<html>
    <head>
       <?php
        echo $metarefresh;
	pclose(popen(mute . ' &', 'r'))
        ?>
    </head>
</html>
