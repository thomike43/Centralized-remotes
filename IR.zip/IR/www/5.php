<?php
$metarefresh = '<meta http-equiv="refresh" content="0; url=/" />';
?>
<html>
    <head>
       <?php
        echo $metarefresh;
	pclose(popen(5 . ' &', 'r'))
        ?>
    </head>
</html>
